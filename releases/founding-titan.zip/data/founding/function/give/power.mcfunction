function founding:power/inherit
